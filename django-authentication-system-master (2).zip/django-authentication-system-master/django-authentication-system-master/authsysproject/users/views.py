import imp
from django.shortcuts import render, redirect
from django.contrib import messages,auth
from users.models import reee
from users.forms import UserRegisterForm


def home(request):
    return render(request, 'users/home.html')


def register(request):
    if request.method == "POST":
        forms = UserRegisterForm(request.POST)
        if forms.is_valid():
           
            forms.save()
            username = forms.cleaned_data.get('username')
            messages.success(request, f'Hi {username}, your account was created successfully')
            return redirect('home')
    else:
        forms = UserRegisterForm()

    return render(request, 'users/register.html', {'forms': forms})


"""@login_required()
def profile(request):
    return render(request, 'users/profile.html')"""
